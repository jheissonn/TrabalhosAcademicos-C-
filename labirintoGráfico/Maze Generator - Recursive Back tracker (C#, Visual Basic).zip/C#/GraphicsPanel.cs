﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class GraphicsPanel : System.Windows.Forms.Panel
    {
        public GraphicsPanel()
        {
            this.DoubleBuffered = true;
        }
    }
}
